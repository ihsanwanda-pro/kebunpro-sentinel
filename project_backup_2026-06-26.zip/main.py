from flask import Flask, jsonify, render_template
import requests
import datetime
from agronomy import calculate_feasibility, DEFAULT_CONFIG

app = Flask(__name__)

# Preset coordinates (e.g., Riau)
LATITUDE = 0.507
LONGITUDE = 101.447

def fetch_weather_forecast():
    weather_url = f"https://api.open-meteo.com/v1/forecast?latitude={LATITUDE}&longitude={LONGITUDE}&daily=temperature_2m_max,precipitation_sum,wind_speed_10m_max,relative_humidity_2m_max,et0_fao_evapotranspiration&timezone=Asia%2FSingapore"
    soil_url = f"https://api.open-meteo.com/v1/forecast?latitude={LATITUDE}&longitude={LONGITUDE}&hourly=soil_moisture_0_to_7cm,soil_moisture_7_to_28cm,soil_temperature_0_to_7cm&timezone=Asia%2FSingapore"
    
    r_weather = requests.get(weather_url).json()
    r_soil = requests.get(soil_url).json()
    
    daily = r_weather.get("daily", {})
    hourly = r_soil.get("hourly", {})
    
    if not daily or not hourly:
        return []

    # Process hourly soil data to daily averages
    # Group hourly by day manually to avoid pandas dependency in this lightweight endpoint if possible, 
    # but since pandas is already in the project, we could use it. However, doing it in pure python is faster for Replit.
    soil_daily = {}
    times = hourly.get("time", [])
    moistures = hourly.get("soil_moisture_0_to_7cm", [])
    
    for i, time_str in enumerate(times):
        date_str = time_str.split("T")[0]
        if date_str not in soil_daily:
            soil_daily[date_str] = {"sum": 0, "count": 0}
        
        m = moistures[i]
        if m is not None:
            soil_daily[date_str]["sum"] += m
            soil_daily[date_str]["count"] += 1

    for date_str in soil_daily:
        if soil_daily[date_str]["count"] > 0:
            soil_daily[date_str]["avg"] = soil_daily[date_str]["sum"] / soil_daily[date_str]["count"]
        else:
            soil_daily[date_str]["avg"] = 0.30 # fallback

    forecast_data = []
    dates = daily.get("time", [])
    for i, date_str in enumerate(dates):
        temp_max = daily["temperature_2m_max"][i]
        rain = daily["precipitation_sum"][i]
        wind_speed = daily["wind_speed_10m_max"][i]
        humidity = daily["relative_humidity_2m_max"][i]
        
        soil_moisture = soil_daily.get(date_str, {}).get("avg", 0.30)

        weather_data = {
            "temp_max": temp_max if temp_max is not None else 28.0,
            "rain": rain if rain is not None else 0.0,
            "wind_speed": wind_speed if wind_speed is not None else 10.0,
            "humidity": humidity if humidity is not None else 75.0,
            "soil_moisture": soil_moisture
        }
        
        scores = calculate_feasibility(weather_data, DEFAULT_CONFIG)
        
        forecast_data.append({
            "date": date_str,
            "weather": weather_data,
            "scores": scores
        })
        
    return forecast_data

@app.route("/")
def index():
    return render_template("dashboard.html")

@app.route("/api/forecast")
def forecast_api():
    try:
        data = fetch_weather_forecast()
        return jsonify({"status": "success", "data": data})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
