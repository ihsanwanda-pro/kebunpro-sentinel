document.addEventListener('DOMContentLoaded', () => {
    fetchForecast();
});

function fetchForecast() {
    fetch('/api/forecast')
        .then(response => response.json())
        .then(res => {
            if (res.status === 'success') {
                renderForecast(res.data);
                document.getElementById('loading').classList.add('hidden');
                document.getElementById('dashboard').classList.remove('hidden');
            } else {
                showError("Gagal mengambil data: " + res.message);
            }
        })
        .catch(err => {
            showError("Kesalahan jaringan: " + err.message);
        });
}

function showError(msg) {
    document.getElementById('loading').innerHTML = `<p style="color:red">${msg}</p>`;
}

function renderForecast(data) {
    const list = document.getElementById('forecast-list');
    list.innerHTML = ''; // Clear
    const template = document.getElementById('card-template');

    data.forEach((dayData, index) => {
        const clone = template.content.cloneNode(true);
        const card = clone.querySelector('.forecast-card');

        // Date formatting
        const dateObj = new Date(dayData.date);
        const dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        let dayName = dayNames[dateObj.getDay()];
        
        if (index === 0) dayName = "Hari Ini";
        else if (index === 1) dayName = "Besok";

        const formattedDate = dateObj.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });

        card.querySelector('.day-name').textContent = dayName;
        card.querySelector('.full-date').textContent = formattedDate;

        // Weather summary
        card.querySelector('.temp').textContent = `${Math.round(dayData.weather.temp_max)}°C`;
        card.querySelector('.rain').textContent = `🌧️ ${dayData.weather.rain}mm`;

        // Operation Scores
        setupOperation(card, 'fertilizer', dayData.scores.fertilizer);
        setupOperation(card, 'harvesting', dayData.scores.harvesting);
        setupOperation(card, 'spraying', dayData.scores.spraying);

        // Weather Details
        card.querySelector('.wind-speed').textContent = `${dayData.weather.wind_speed} km/j`;
        card.querySelector('.humidity').textContent = `${dayData.weather.humidity}%`;
        card.querySelector('.soil').textContent = `${Math.round(dayData.weather.soil_moisture * 100)}% Vol`;

        // Default expand first card
        if (index === 0) {
            card.classList.add('expanded');
        }

        list.appendChild(card);
    });
}

function setupOperation(card, opKey, score) {
    const item = card.querySelector(`[data-op="${opKey}"]`);
    const statusText = item.querySelector('.op-status-text');

    let text = "";
    let className = "";

    if (score >= 80) {
        text = "Aman dilakukan";
        className = "status-green";
    } else if (score >= 50) {
        text = "Hati-hati (Catatan cuaca)";
        className = "status-yellow";
    } else {
        text = "Tunda (Berisiko)";
        className = "status-red";
    }

    item.classList.add(className);
    statusText.textContent = text;
}

function toggleDetails(headerEl) {
    const card = headerEl.closest('.forecast-card');
    card.classList.toggle('expanded');
}
